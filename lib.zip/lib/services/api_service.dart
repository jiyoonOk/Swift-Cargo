import 'package:dio/dio.dart';
import 'package:fast_1/models/hscode_model.dart';
import 'package:fast_1/models/user_quote_model.dart';
import 'package:fast_1/constants/urls.dart';

class APIService {
  late Dio
      _dio; // Dio 인스턴스 생성. API 호출을 위한 Dio 객체. dio는 HTTP 클라이언트 라이브러리로 REST API 호출을 위한 기능을 제공. get 요청, post 요청 등을 보낼 수 있음.

  // API의 기본 URL 설정
  final String baseUrl = URLs.baseUrl;

  // Dio 인스턴스 생성. 기능: API 호출
  APIService() {
    _dio = Dio(BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: Duration(milliseconds: 3000),
      receiveTimeout: Duration(milliseconds: 3000),
    ));
  }

  // 응답 처리 메서드
  Future<dynamic> _handleApiResponse(Response response) async {
    if (response.statusCode == 200 || response.statusCode == 201) {
      return response.data as dynamic;
    } else {
      throw Exception(
          'Failed to process request: Status ${response.statusCode}');
    }
  }

  // HSCode 정보를 가져오는 메서드. Future: 비동기 처리를 위한 Future 객체 반환
  Future<List<HSCode>> fetchHSCodes() async {
    try {
      Response response =
          await _dio.get(URLs.hsCodeSearch); // Dio를 사용하여 GET 요청을 보냄
      var data = await _handleApiResponse(response); // 응답 처리 메서드 호출
      return (data as List).map((x) => HSCode.fromJson(x)).toList();
    } catch (e) {
      throw Exception('Failed to load HS Codes: ${e.toString()}');
    }
  }

  // 사용자 견적 정보를 가져오는 메서드
  Future<List<UserQuote>> fetchUserQuotes() async {
    try {
      Response response = await _dio.get(URLs.userQuotes);
      var data = await _handleApiResponse(response);
      return (data as List).map((x) => UserQuote.fromJson(x)).toList();
    } catch (e) {
      throw Exception('Failed to load User Quotes: ${e.toString()}');
    }
  }

  // 견적 정보를 생성하는 메서드
  Future<UserQuote> createUserQuote(UserQuote quote) async {
    //UserQuote 객체를 인자로 받아서 API 호출
    try {
      print('Sending data to server: ${quote.toJson()}'); // 요청 데이터 로깅

      Response response = await _dio.post(URLs.userQuotes,
          data: quote.toJson()); //POST 요청을 보내기 위해 _dio.post()를 사용.
      var data = await _handleApiResponse(response);
      return UserQuote.fromJson(data);
    } catch (e) {
      throw Exception('Failed to create User Quote: ${e.toString()}');
    }
  }

  // 견적 정보를 업데이트하는 메서드
  Future<UserQuote> updateUserQuote(UserQuote quote) async {
    try {
      Response response =
          await _dio.put(URLs.updateUserQuote, data: quote.toJson());
      var data = await _handleApiResponse(response);
      return UserQuote.fromJson(data);
    } catch (e) {
      throw Exception('Failed to update User Quote: ${e.toString()}');
    }
  }

  // 견적 정보를 삭제하는 메서드
  Future<void> deleteUserQuote(int quoteId) async {
    try {
      Response response = await _dio.delete(URLs.deleteUserQuote);
      await _handleApiResponse(response);
    } catch (e) {
      throw Exception('Failed to delete User Quote: ${e.toString()}');
    }
  }
}

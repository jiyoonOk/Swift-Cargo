// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'quote_image_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

QuoteImage _$QuoteImageFromJson(Map<String, dynamic> json) => QuoteImage(
      path: json['path'] as String,
    );

Map<String, dynamic> _$QuoteImageToJson(QuoteImage instance) =>
    <String, dynamic>{
      'path': instance.path,
    };
